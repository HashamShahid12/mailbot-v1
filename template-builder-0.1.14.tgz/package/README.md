# Template Builder - Drag & Drop Email Editor

A powerful, customizable React component for building responsive email templates with drag-and-drop functionality.

## Features

- 🎨 **Drag & Drop Interface**: Intuitive builder with a wide range of pre-built components.
- 📱 **Responsive Design**: Mobile and desktop preview modes.
- 🔧 **Customizable**: Extensive styling options for global settings and individual components.
- 💾 **Save & Export**: Export to HTML (email-ready) or JSON (for storage).
- 🔄 **Undo/Redo**: Full history support.
- 🧩 **Merge Tags**: Support for dynamic content insertion.

## Installation

```bash
npm install template-builder
# OR if installing from local tarball
npm install ./path/to/template-builder-0.1.13.tgz
```

## Usage

### 1. Import Styles

Import the CSS file in your root entry point (e.g., `main.tsx`, `App.tsx`, or `index.js`).

```javascript
import "template-builder/style.css";
```

### 2. Basic Implementation

```tsx
import { useState } from "react";
import { EmailEditor, EmailTemplate } from "template-builder";

function App() {
  const [isLoading, setIsLoading] = useState(false);

  const handleSave = (html: string, json: string, name: string) => {
    console.log("Saving template:", name);
    setIsLoading(true);

    // Simulate API call
    setTimeout(() => {
      setIsLoading(false);
      console.log("Saved!");
    }, 1000);
  };

  return (
    <div style={{ height: "100vh" }}>
      <EmailEditor
        onSave={handleSave}
        loading={isLoading}
        onBack={() => console.log("Go back")}
      />
    </div>
  );
}
```

## Component API

### `<EmailEditor />` Props

| Prop              | Type                                                 | Description                                                                     |
| ----------------- | ---------------------------------------------------- | ------------------------------------------------------------------------------- |
| `initialTemplate` | `EmailTemplate`                                      | (Optional) Initial template data to load into the editor.                       |
| `onSave`          | `(html: string, json: string, name: string) => void` | Callback triggered when the user clicks "Save" on a **new** template.           |
| `onUpdate`        | `(html: string, json: string, name: string) => void` | Callback triggered when the user clicks "Save" on an **existing** template.     |
| `onBack`          | `() => void`                                         | Callback for the "Back" button in the top bar.                                  |
| `loading`         | `boolean`                                            | If `true`, shows a full-screen loading overlay over the editor.                 |
| `saveButtonText`  | `string`                                             | (Optional) Custom text for the save button. Defaults to "Save".                 |
| `onUploadImage`   | `(file: File) => Promise<string>`                    | (Optional) Async function to handle image uploads. Should return the image URL. |
| `mergeTags`       | `object`                                             | Configuration for available merge tags (see structure below).                   |

### Callback Parameters

- **`html`**: The generated HTML string, ready to be sent in an email. Includes inline styles and responsive table structures.
- **`json`**: The JSON string representation of the template state. Store this in your database to reload the template later.
- **`name`**: The name of the template provided by the user.

## Merge Tags Configuration

You can pass a configuration object to `mergeTags` to allow users to insert dynamic variables (like `{{first_name}}`).

```javascript
const mergeTagsConfig = {
  // Simple tags
  first_name: {
    name: "First Name",
    value: "{{first_name}}",
  },

  // Grouped tags (e.g., for loops)
  products: {
    name: "Products List",
    rules: {
      repeat: {
        name: "Repeat for Each Product",
        before: "{{#products}}",
        after: "{{/products}}",
      },
    },
    mergeTags: {
      product_name: {
        name: "Product Name",
        value: "{{product_name}}",
      },
      product_price: {
        name: "Product Price",
        value: "{{product_price}}",
      },
    },
  },
};
```

## Types Reference

### `EmailTemplate`

Use this type when loading a saved template via `initialTemplate`.

```typescript
interface EmailTemplate {
  id: string;
  name: string;
  category: "newsletter" | "ecommerce" | "real-estate" | "custom";
  components: EmailComponent[];
  thumbnail?: string;
  description?: string;
}
```

## Example: Loading a Saved Template

```tsx
import { EmailEditor, EmailTemplate } from "template-builder";

const mySavedTemplate: EmailTemplate = {
  id: "123",
  name: "My Newsletter",
  category: "custom",
  components: [
    // ... components data from your database
  ],
};

function EditTemplatePage() {
  return (
    <EmailEditor
      initialTemplate={mySavedTemplate}
      onUpdate={(html, json, name) => {
        // Update logic here
        console.log("Updated HTML length:", html.length);
      }}
    />
  );
}
```
